package com.example.asa.mixin;

import com.example.asa.ASAClient;
import com.example.asa.ASAConfig;
import com.example.asa.ASAState;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_329;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public class InGameHudMixin {
    @Inject(method = "setTitle", at = @At("HEAD"))
    private void onSetTitle(class_2561 title, CallbackInfo ci) {
        handleText(title);
    }

    @Inject(method = "setSubtitle", at = @At("HEAD"))
    private void onSetSubtitle(class_2561 subtitle, CallbackInfo ci) {
        handleText(subtitle);
    }

    private void handleText(class_2561 text) {
        if (!ASAConfig.enabled || text == null) return;

        String content = text.getString();
        // 匹配图片中的文字：醒醒！ 请在聊天框发送你要反馈的内容
        if (content.contains("醒醒") || (content.contains("发送") && content.contains("反馈") && content.contains("内容"))) {
            if (ASAClient.currentState == ASAState.WAITING_TITLE) {
                class_310 client = class_310.method_1551();
                client.execute(() -> {
                    if (client.field_1724 != null) {
                        client.field_1724.field_3944.method_45729(ASAConfig.appealReason);
                        ASAClient.currentState = ASAState.FINISHING;
                        client.field_1724.method_7353(class_2561.method_43470("§7[ASA] §a检测到 Title，已发送申诉内容。"), false);
                    }
                });
            }
        }
    }
}
