package com.example.asa.mixin;

import com.example.asa.ASAClient;
import com.example.asa.ASAConfig;
import com.example.asa.ASAState;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_329;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public class InGameHudMixin {
    @Inject(method = "setTitle", at = @At("HEAD"))
    private void onSetTitle(class_2561 title, CallbackInfo ci) {
        if (!ASAConfig.enabled) return;

        String titleStr = title.getString();
        // Step 6: 识别 Title "请在聊天框发送..."
        if (titleStr.contains("发送你反馈的内容")) {
            if (ASAClient.currentState == ASAState.WAITING_TITLE) {
                // 延迟 1 tick 发送
                class_310 client = class_310.method_1551();
                client.execute(() -> {
                    if (client.field_1724 != null) {
                        client.field_1724.field_3944.method_45729(ASAConfig.appealReason);
                        ASAClient.currentState = ASAState.FINISHING;
                    }
                });
            }
        }
    }
}
