package com.example.asa.mixin;

import com.example.asa.ASAClient;
import com.example.asa.ASAState;
import net.minecraft.class_309;
import net.minecraft.class_310;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_309.class)
public class KeyboardMixin {
    @Inject(method = "onKey", at = @At("HEAD"), cancellable = true)
    private void onKey(long window, int key, int scancode, int action, int mods, CallbackInfo ci) {
        // 如果自动化正在运行
        if (ASAClient.currentState != ASAState.IDLE) {
            // 允许 ESC 键退出自动化
            if (key == GLFW.GLFW_KEY_ESCAPE) {
                ASAClient.currentState = ASAState.IDLE;
                class_310.method_1551().field_1724.method_7353(net.minecraft.class_2561.method_43470("§7[ASA] §c用户干预，已手动停止任务。"), false);
                return;
            }
            
            // 屏蔽其他所有按键
            ci.cancel();
        }
    }
}
