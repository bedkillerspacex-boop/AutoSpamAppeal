package com.example.asa.mixin;

import com.example.asa.ASAConfig;
import com.example.asa.ASAUtils;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_419;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_419.class)
public abstract class DisconnectedScreenMixin extends class_437 {
    @Unique
    private class_2561 asa$capturedReason;

    protected DisconnectedScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method = "<init>(Lnet/minecraft/client/gui/screen/Screen;Lnet/minecraft/text/Text;Lnet/minecraft/text/Text;)V", at = @At("TAIL"))
    private void onInit3(class_437 parent, class_2561 title, class_2561 reason, CallbackInfo ci) {
        this.asa$capturedReason = reason;
    }

    @Inject(method = "<init>(Lnet/minecraft/client/gui/screen/Screen;Lnet/minecraft/text/Text;Lnet/minecraft/text/Text;Lnet/minecraft/text/Text;)V", at = @At("TAIL"))
    private void onInit4(class_437 parent, class_2561 title, class_2561 reason, class_2561 buttonLabel, CallbackInfo ci) {
        this.asa$capturedReason = reason;
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void onInitScreen(CallbackInfo ci) {
        if (!ASAConfig.enabled || this.asa$capturedReason == null) return;

        String reasonStr = this.asa$capturedReason.getString();
        // Step 1: 检测 Banned 消息，或者由于申诉完成导致的断开
        boolean isBan = reasonStr.contains("封禁") || reasonStr.contains("Banned") || reasonStr.contains("检测到") || reasonStr.contains("Spam");
        boolean isManualDisconnect = reasonStr.contains("Disconnected") || reasonStr.contains("连接已断开");

        if (isBan || isManualDisconnect) {
            ASAConfig.lastBanMessage = isBan ? reasonStr : ASAConfig.lastBanMessage;
            // 延迟重连
            new Thread(() -> {
                try {
                    Thread.sleep(1000); // 1秒后重连
                    class_310.method_1551().execute(() -> {
                        ASAUtils.reconnect(class_310.method_1551());
                    });
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }).start();
        }
    }
}
