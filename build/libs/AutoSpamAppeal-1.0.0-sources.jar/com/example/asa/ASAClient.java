package com.example.asa;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1713;
import net.minecraft.class_2246;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2828;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_476;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import org.lwjgl.glfw.GLFW;

public class ASAClient implements ClientModInitializer {
    public static ASAState currentState = ASAState.IDLE;
    private long lastActionTime = 0;
    private int tickDelay = 0;

    private static class_304 configKey;

    @Override
    public void onInitializeClient() {
        configKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.autospamappeal.config",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_O,
            "category.autospamappeal"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (configKey.method_1436()) {
                client.method_1507(new ASAScreen());
            }
            this.onTick(client);
        });

        // Step 7: 检测聊天栏绿色提示并断开连接
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (!ASAConfig.enabled) return;
            String content = message.getString();
            if (content.contains("反馈成功") || content.contains("Success")) {
                if (currentState == ASAState.FINISHING) {
                    class_310.method_1551().execute(() -> {
                        if (class_310.method_1551().field_1687 != null) {
                            class_310.method_1551().field_1687.method_8525();
                            currentState = ASAState.IDLE;
                        }
                    });
                }
            }
        });
    }

    private void onTick(class_310 client) {
        if (!ASAConfig.enabled || client.field_1724 == null || client.field_1687 == null) return;

        if (tickDelay > 0) {
            tickDelay--;
            return;
        }

        switch (currentState) {
            case IDLE -> {
                // 如果在某些特定情况下需要自动开始，可以在这里触发
                // 比如刚进服务器时
                if (client.field_1724.method_31549().field_7480) { // 简单判断是否在保护期/初始点
                     currentState = ASAState.CHECKING_BLOCK;
                }
            }

            case CHECKING_BLOCK -> {
                // Step 2: 检测脚底方块 (图1中的方块，这里暂定为暗橡木板，请根据实际修改)
                if (client.field_1687.method_8320(client.field_1724.method_24515().method_10074()).method_27852(class_2246.field_10075)) {
                    client.field_1724.method_7353(class_2561.method_43470("§7[ASA] §a开始申诉..."), false);
                    currentState = ASAState.TELEPORTING;
                    tickDelay = 10;
                }
            }

            case TELEPORTING -> {
                // Step 3: TP 14 -59 14 (针对原版限制)
                // 发送位置包
                client.field_1724.field_3944.method_52787(new class_2828.class_2829(14.5, -59.0, 14.5, true, true));
                client.field_1724.method_5814(14.5, -59.0, 14.5);
                currentState = ASAState.ATTACKING;
                tickDelay = 5;
            }

            case ATTACKING -> {
                // Step 3: 攻击最近的假人 (Bot)
                class_1297 target = null;
                double minDesk = 5.0;
                class_243 playerPos = client.field_1724.method_19538();

                for (class_1297 entity : client.field_1687.method_18112()) {
                    if (entity != client.field_1724) {
                        double dist = entity.method_19538().method_1022(playerPos);
                        if (dist < minDesk) {
                            target = entity;
                            minDesk = dist;
                        }
                    }
                }

                if (target != null) {
                    client.field_1761.method_2918(client.field_1724, target);
                    currentState = ASAState.GUI_MAIN;
                    tickDelay = 20; // 等待 GUI 打开
                }
            }

            case GUI_MAIN -> {
                // Step 4: 处理 GUI (红石块)
                if (client.field_1755 instanceof class_476 screen) {
                    if (screen.method_25440().getString().contains("反馈系统")) {
                        // 寻找红石块
                        for (int i = 0; i < screen.method_17577().field_7761.size(); i++) {
                            var stack = screen.method_17577().method_7611(i).method_7677();
                            if (stack.method_31574(net.minecraft.class_1802.field_8793)) {
                                clickSlot(client, screen, i);
                                currentState = ASAState.GUI_SUB;
                                tickDelay = 20;
                                return;
                            }
                        }
                    }
                }
            }

            case GUI_SUB -> {
                // Step 5: 处理子 GUI (骷髅头)
                if (client.field_1755 instanceof class_476 screen) {
                    if (screen.method_25440().getString().contains("选择子类型")) {
                        for (int i = 0; i < screen.method_17577().field_7761.size(); i++) {
                            var stack = screen.method_17577().method_7611(i).method_7677();
                            if (stack.method_31574(net.minecraft.class_1802.field_8575)) {
                                if (stack.method_7964().getString().contains("自述申诉")) {
                                    clickSlot(client, screen, i);
                                    currentState = ASAState.WAITING_TITLE;
                                    tickDelay = 5;
                                    return;
                                }
                            }
                        }
                    }
                }
            }
            
            case WAITING_TITLE -> {
                // 逻辑在 Mixin 中处理，或者检测 GUI 关闭
                if (client.field_1755 == null) {
                    // GUI 已关闭，准备发送消息
                    // 状态转换由 Mixin 触发或在此处计时
                }
            }
        }
    }

    private void clickSlot(class_310 client, class_476 screen, int slotId) {
        client.field_1761.method_2906(screen.method_17577().field_7763, slotId, 0, class_1713.field_7790, client.field_1724);
    }
}
