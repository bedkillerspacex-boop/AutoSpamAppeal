package com.example.asa;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1713;
import net.minecraft.class_2246;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2828;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3481;
import net.minecraft.class_3675;
import net.minecraft.class_476;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import org.lwjgl.glfw.GLFW;

public class ASAClient implements ClientModInitializer {
    public static ASAState currentState = ASAState.IDLE;
    public static int tickDelay = 0;

    private static class_304 configKey;
    private static class_304 forceStartKey;

    @Override
    public void onInitializeClient() {
        ASAConfig.load();
        
        configKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.autospamappeal.config",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_O,
            "category.autospamappeal"
        ));

        forceStartKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.autospamappeal.force",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_P,
            "category.autospamappeal"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null) return;
            
            while (configKey.method_1436()) {
                client.method_1507(new ASAScreen());
            }
            while (forceStartKey.method_1436()) {
                currentState = ASAState.TELEPORTING;
                client.field_1724.method_7353(class_2561.method_43470("§7[ASA] §e强制开始申诉流程..."), false);
            }
            this.onTick(client);
        });

        // Step 7: 检测聊天栏绿色提示并断开连接
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (!ASAConfig.enabled) return;
            String content = message.getString();
            boolean isFinished = content.contains("反馈成功") || content.contains("Success") || 
                                 content.contains("反馈失败") || content.contains("Failed") || 
                                 content.contains("拒绝") || content.contains("Denied");

            if (isFinished) {
                if (currentState == ASAState.FINISHING) {
                    boolean success = content.contains("反馈成功") || content.contains("Success");
                    String result = success ? "§a成功" : "§c失败";
                    
                    class_310.method_1551().field_1724.method_7353(class_2561.method_43470("§7[ASA] §f申诉结果: " + result), false);
                    class_310.method_1551().field_1724.method_7353(class_2561.method_43470("§7[ASA] §f发送内容: §e" + ASAConfig.appealReason), false);
                    
                    // 等待 0.1 秒后退出
                    tickDelay = 2; 
                    new Thread(() -> {
                        try {
                            Thread.sleep(100); // 0.1秒
                            class_310.method_1551().execute(() -> {
                                if (class_310.method_1551().field_1687 != null && currentState == ASAState.FINISHING) {
                                    class_310.method_1551().field_1687.method_8525();
                                    currentState = ASAState.IDLE;
                                }
                            });
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }).start();
                }
            }
        });
    }

    private void onTick(class_310 client) {
        if (!ASAConfig.enabled || client.field_1724 == null || client.field_1687 == null) return;

        // 调试信息：在 Action Bar 显示当前状态
        if (ASAConfig.showDebug) {
            if (currentState != ASAState.IDLE && tickDelay == 0) {
                client.field_1724.method_7353(class_2561.method_43470("§b[ASA 状态] §f" + currentState.name()), true);
            } else if (tickDelay > 0 && currentState == ASAState.IDLE) {
                client.field_1724.method_7353(class_2561.method_43470("§c[ASA 冷却中] §f" + (tickDelay / 20 + 1) + "s"), true);
            }
        }

        if (tickDelay > 0) {
            tickDelay--;
            return;
        }

        switch (currentState) {
            case RECONNECTING -> {
                currentState = ASAState.IDLE;
            }

            case IDLE -> {
                // 启用后立即进入检测阶段
                currentState = ASAState.CHECKING_BLOCK;
            }

            case CHECKING_BLOCK -> {
                // 新增坐标限制：X: 12.5 +/- 5, Z: 10.5 +/- 5, Y: 必须是 -59
                double playerX = client.field_1724.method_23317();
                double playerY = client.field_1724.method_23318();
                double playerZ = client.field_1724.method_23321();

                boolean inPosition = Math.abs(playerX - 12.5) <= 5.0 && 
                                   Math.abs(playerZ - 10.5) <= 5.0 && 
                                   (int)Math.floor(playerY) == -59;

                if (!inPosition) return;

                // Step 2: 检测脚底方块 3x3 范围内是否有 5 个以上目标方块
                int matchCount = 0;
                var basePos = client.field_1724.method_24515().method_10074();
                
                for (int x = -1; x <= 1; x++) {
                    for (int z = -1; z <= 1; z++) {
                        var pos = basePos.method_10069(x, 0, z);
                        var state = client.field_1687.method_8320(pos);
                        if (state.method_26164(class_3481.field_15471) || 
                            state.method_27852(class_2246.field_10508) || 
                            state.method_27852(class_2246.field_10346) ||
                            state.method_27852(class_2246.field_10115) ||
                            state.method_27852(class_2246.field_10474)) {
                            matchCount++;
                        }
                    }
                }

                if (matchCount >= 5) {
                    client.field_1724.method_7353(class_2561.method_43470("§7[ASA] §a检测到周围有 " + matchCount + " 个目标方块，开始申诉..."), false);
                    currentState = ASAState.TELEPORTING;
                    tickDelay = 1;
                }
            }

            case TELEPORTING -> {
                // Step 3: TP 14 -59 14
                client.field_1724.field_3944.method_52787(new class_2828.class_2829(14.5, -59.0, 14.5, true, true));
                client.field_1724.method_5814(14.5, -59.0, 14.5);
                currentState = ASAState.ATTACKING;
                tickDelay = 1;
            }

            case ATTACKING -> {
                // Step 3: 攻击最近的假人
                class_1297 target = null;
                double minDesk = 5.0;
                class_243 playerPos = client.field_1724.method_19538();

                for (class_1297 entity : client.field_1687.method_18112()) {
                    if (entity != client.field_1724) {
                        double dist = entity.method_19538().method_1022(playerPos);
                        if (dist < minDesk) {
                            target = entity;
                            minDesk = dist;
                        }
                    }
                }

                if (target != null) {
                    client.field_1761.method_2918(client.field_1724, target);
                    currentState = ASAState.GUI_MAIN;
                    tickDelay = 2; // 稍长的等待，确保 GUI 开启
                }
            }

            case GUI_MAIN -> {
                // Step 4: 处理主 GUI
                if (client.field_1755 instanceof class_476 screen) {
                    if (screen.method_25440().getString().contains("反馈系统")) {
                        for (int i = 0; i < screen.method_17577().field_7761.size(); i++) {
                            var stack = screen.method_17577().method_7611(i).method_7677();
                            if (stack.method_31574(net.minecraft.class_1802.field_8793)) {
                                clickSlot(client, screen, i);
                                currentState = ASAState.GUI_SUB;
                                tickDelay = 2;
                                return;
                            }
                        }
                    }
                }
            }

            case GUI_SUB -> {
                // Step 5: 处理子 GUI
                if (client.field_1755 instanceof class_476 screen) {
                    if (screen.method_25440().getString().contains("选择子类型")) {
                        for (int i = 0; i < screen.method_17577().field_7761.size(); i++) {
                            var stack = screen.method_17577().method_7611(i).method_7677();
                            if (stack.method_31574(net.minecraft.class_1802.field_8575) || stack.method_31574(net.minecraft.class_1802.field_8398)) {
                                if (stack.method_7964().getString().contains("自述申诉")) {
                                    clickSlot(client, screen, i);
                                    currentState = ASAState.WAITING_TITLE;
                                    tickDelay = 1;
                                    return;
                                }
                            }
                        }
                    }
                }
            }
            
            case WAITING_TITLE -> {
                // Mixin 处理发送
                if (client.field_1755 == null && tickDelay == 0) {
                     // 如果长时间没识别到 Title，重置状态
                     // 可以在这里加超时处理
                }
            }
        }
    }

    private void clickSlot(class_310 client, class_476 screen, int slotId) {
        client.field_1761.method_2906(screen.method_17577().field_7763, slotId, 0, class_1713.field_7790, client.field_1724);
    }
}
