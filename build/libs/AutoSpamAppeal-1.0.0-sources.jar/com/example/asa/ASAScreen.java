package com.example.asa;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class ASAScreen extends class_437 {
    private class_342 reasonField;

    public ASAScreen() {
        super(class_2561.method_43470("ASA 设置"));
    }

    @Override
    protected void method_25426() {
        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;

        // 开关按钮
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("ASA 状态: " + (ASAConfig.enabled ? "§a开启" : "§c关闭")),
            button -> {
                ASAConfig.enabled = !ASAConfig.enabled;
                button.method_25355(class_2561.method_43470("ASA 状态: " + (ASAConfig.enabled ? "§a开启" : "§c关闭")));
                ASAConfig.save();
            }
        ).method_46434(centerX - 100, centerY - 50, 200, 20).method_46431());

        // 调试信息开关按钮
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("调试信息: " + (ASAConfig.showDebug ? "§a显示" : "§c隐藏")),
            button -> {
                ASAConfig.showDebug = !ASAConfig.showDebug;
                button.method_25355(class_2561.method_43470("调试信息: " + (ASAConfig.showDebug ? "§a显示" : "§c隐藏")));
                ASAConfig.save();
            }
        ).method_46434(centerX - 100, centerY - 25, 200, 20).method_46431());

        // 理由输入框 (向下移动一点以避开新按钮)
        this.reasonField = new class_342(this.field_22793, centerX - 100, centerY + 10, 200, 20, class_2561.method_43470("申诉理由"));
        this.reasonField.method_1880(128);
        this.reasonField.method_1852(ASAConfig.appealReason);
        this.method_37063(this.reasonField);

        // 保存按钮
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("保存并关闭"),
            button -> {
                ASAConfig.appealReason = this.reasonField.method_1882();
                ASAConfig.save();
                this.method_25419();
            }
        ).method_46434(centerX - 100, centerY + 40, 200, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 20, 0xFFFFFF);
        context.method_25303(this.field_22793, "申诉理由:", this.field_22789 / 2 - 100, this.field_22790 / 2 + 0, 0xFFFFFF);
    }
}
