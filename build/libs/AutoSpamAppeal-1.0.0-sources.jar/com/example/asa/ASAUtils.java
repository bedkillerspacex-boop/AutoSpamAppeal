package com.example.asa;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_412;
import net.minecraft.class_442;
import net.minecraft.class_639;
import net.minecraft.class_642;

public class ASAUtils {
    public static class_642 lastServerInfo;

    public static void reconnect(class_310 client) {
        class_642 info = client.method_1558() != null ? client.method_1558() : lastServerInfo;
        if (info != null) {
            if (client.field_1724 != null) {
                client.field_1724.method_7353(class_2561.method_43470("§7[ASA] §e正在尝试重连至: " + info.field_3761), false);
            }
            class_412.method_36877(new class_442(), client, class_639.method_2950(info.field_3761), info, false, null);
            ASAClient.currentState = ASAState.RECONNECTING;
        } else {
            System.out.println("[ASA] 无法重连：未找到服务器信息");
        }
    }
}
