package com.example.asa;

import net.minecraft.class_310;
import net.minecraft.class_412;
import net.minecraft.class_442;
import net.minecraft.class_639;
import net.minecraft.class_642;

public class ASAUtils {
    public static void reconnect(class_310 client) {
        class_642 info = client.method_1558();
        if (info != null) {
            class_412.method_36877(new class_442(), client, class_639.method_2950(info.field_3761), info, false, null);
            ASAClient.currentState = ASAState.RECONNECTING;
        }
    }
}
